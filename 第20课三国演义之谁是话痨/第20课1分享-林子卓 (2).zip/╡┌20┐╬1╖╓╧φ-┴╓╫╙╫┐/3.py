#十进制转16进制
ls={0: '0',1: '1',2: '2',3: '3',4: '4',5: '5',6: '6', \
    7: '7',8: '10',9: '11',10: 'A',11: 'B',12: 'C',13: 'D',14: 'E',15: 'F'}
ls1=[]
x=ord('国')
print(x)
while(1):
    if(x<16):
        ls1.append(x)
        break
    l=x%16
    if(l!=0):
        ls1.append(ls[l])
    x=x//16
z=''
for i in range(len(ls1)):
    z+=str(ls1[len(ls1)-i-1])
print(z)
