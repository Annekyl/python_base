#合并单元格并写入数据
import openpyxl
from openpyxl import load_workbook
wk=load_workbook('2.xlsx')
wc=wk['2']
wc.merge_cells(start_row=(1),start_column=(1),end_row=(1),end_column=(3))
wc.merge_cells('A3:B4')
wc.cell(row=1,column=1).value=1#将单元格合并即为隐藏其余单元格只留下第一个单元格 未合并的单元格序列不变
wk.save('2.xlsx')