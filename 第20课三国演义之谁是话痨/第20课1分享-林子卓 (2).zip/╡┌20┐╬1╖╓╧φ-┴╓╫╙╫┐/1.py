a='国'
print(ord(a))
#unicode字符可直接用ord函数将其转为对应编码
