#文件解读
import openpyxl
from openpyxl import load_workbook
wk=load_workbook("数据处理.xlsx")
wc=wk['数据处理']
ks=[]
pk={0: 0,1: 1,2: 2,3: 3,4: 4,5: 5,6: 6,7: 7,8: 10,9: 11,10: 'A',11: 'B',12: 'C',13: 'D',14: 'E',15: 'F'}#十进制转十六进制
with open('指定文件.txt', 'r', encoding='utf-8') as r:
    ls=r.readlines()
l=0#l用来更换列
y=0#y用来标记字符序号
def tianru():
    wc.cell(row=(3*l+1),column=k).value=y#填进字符串的序号
    wc.cell(row=(3*l+2),column=k).value=m#填进字符串
    wc.cell(row=(3*l+3),column=k).value=z#填进字符串unicode码的十六进制
def hebing(n):
    wc.merge_cells(start_row=(3*l+1),start_column=k,end_row=(3*l+1),end_column=k+n)
    wc.merge_cells(start_row=(3*l+2),start_column=k,end_row=(3*l+2),end_column=k+n)
    wc.merge_cells(start_row=(3*l+3),start_column=k,end_row=(3*l+3),end_column=k+n)#合并单元格
for i in ls:
    k=1# 初始化变量 k用来确定单元格的位置
    for j in range(len(i)):
        ls1=[]
        y+=1
        if(i[j]==' '):
            m="\\ "
        if(i[j]=='\n'):#将空格和回车反转义为转义字符
            m ="\\n"
        else:
            m = i[j]
        x = ord(i[j])
#----------------将十进制值转为十六进制-------------------------------
        while(1):
            if(x<16):
                ls1.append(x)
                break
            bz=x%16
            if(bz!=0):
                ls1.append(pk[bz])
            x=x//16
        x = ord(i[j])
        z=''
        for j in range(len(ls1)):
            z+=str(ls1[len(ls1)-j-1])
#--------------------判断字节数量------------
        if(128<=x<=2047):
            hebing(1)
            tianru()
            k+=2
        elif(2048<=x<=65535):
            hebing(2)
            tianru()
            k+=3
        elif(65536<=x<=1114111):
            hebing(3)
            tianru()
        else:
            tianru()
            k+=1
    l+=1
wk.save('数据处理.xlsx')
