import openpyxl as o
import subprocess as su
w=o.load_workbook('文本.xlsx')
sheet=w.active
with open('文本.txt','r',encoding='utf-8') as f:
    m=0
    n=0
    for i in f:
        for j in i:
            if ord(j)==10:#检测换行符
                j='\\n'
            m+=1
            n+=1
            er=j.encode('utf-8')#将字符j编码为二进制
            shiliu=''.join(format(i,'02X') for i in er)#02指定了输出的宽度为2,确保生成的16进制字符串始终是两位,而X表示输出为大写字母
            l=0
            if len(shiliu)==6:#检测该字符16进制数长度
                n+=2
                for i in range(3):#向后写三个数字
                    sheet.cell(row=1,column=m+i,value=m+i)
                    sheet.cell(row=4,column=m+i,value=m+i)
                sheet.cell(row=2,column=n-2,value=j)#但只写一个汉字
                sheet.cell(row=5,column=n-2,value=shiliu)
                m+=2
                l=1
            if len(shiliu)==4:
                n+=1
                for i in range(2):
                    sheet.cell(row=1,column=m+i,value=m+i)
                    sheet.cell(row=4,column=m+i,value=m+i)
                sheet.cell(row=2,column=n-1,value=j)
                sheet.cell(row=5,column=n-1,value=shiliu)
                m+=1
                l=2
            if len(shiliu)==2:
                sheet.cell(row=1,column=m,value=m)
                sheet.cell(row=2,column=n,value=j)
                sheet.cell(row=4,column=m,value=m)
                sheet.cell(row=5,column=n,value=shiliu)

            if l==1:#合并单元格
                sheet.merge_cells(start_row=2,start_column=n-2,end_row=2,end_column=n)
                sheet.merge_cells(start_row=5,start_column=n-2,end_row=5,end_column=n)
            if l==2:
                sheet.merge_cells(start_row=2,start_column=n-1,end_row=2,end_column=n)
                sheet.merge_cells(start_row=5,start_column=n-1,end_row=5,end_column=n)

w.save('文本.xlsx')
su.run(['start','文本.xlsx'],shell=True)
