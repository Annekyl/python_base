#————定义部分————
def hebing(n,m):
    sheet.merge_cells(start_row=(n),start_column=(m),end_row=(n),end_column=(m+2))#row表示行,column表示列  
#——————主程序部分——————
#————导入一个自动打开的程序————
import subprocess as su
#————将数据填入列表————
ls=[]
ls0=[]
ls1=[]
ls2=[]
with open("文本内容.txt","r",encoding="utf-8") as f:
    read=f.readlines()
for i in read:#将文本内容存入ls列表中
    for j in range(len(i)):
        ls.append(i[j])

for i in range(len(ls)):#将各个字符转ls0列表中
    if(ls[i]==' '):
        m="\\ "
    if(ls[i]=='\n'):#将空格和回车反转义为转义字符
        m ="\\n"
    else:
        m=ls[i]
    ls0.append(m)


for i in range(len(ls)):#将各个字符的Unicode值转ls1列表中
    ls1.append(ord(ls[i]))

for i in range(len(ls)):#将各个字符的Unicode值转化为16进制并加入ls2列表中
    ls2.append(hex(ord(ls[i]))[2:])
#print(ls1)
#————对excel表进行处理————
#——判断要合并的表格————
'''
if(128<=x<=2047):
elif(2048<=x<=65535):
elif(65536<=x<=1114111):       
else:
'''           
import openpyxl
from openpyxl import load_workbook
date=load_workbook("数据处理.xlsx")#load_workbook表示打开excel表
sheet=date.active#获取当前位置的一个表(只有一个表时可以直接用active来打开)
#b1=sheet.max_row#查找excel表中的最大行数
#b2=sheet.max_column#查找excel表中的最大列数


sheet.cell(row=1,column=1,value="名字")
sheet.cell(row=2,column=1,value="Unicode值")
sheet.cell(row=3,column=1,value="十六进制")
for i in range(len(ls1)):
    b=sheet.max_column
    if 19968<=ls1[i]<=40870:
        for j in range(3):
            hebing(1+j,b+1)
    sheet.cell(row=1, column=b+1, value=str(ls0[i])) #value表示填入的字符串
    sheet.cell(row=2, column=b+1, value=str(ls1[i]))
    sheet.cell(row=3, column=b+1, value=str(ls2[i]))

date=date.save("数据处理.xlsx")#用于结尾将输入的数据添加进excel表格中

su.run(['start',"数据处理.xlsx"],shell=True)
