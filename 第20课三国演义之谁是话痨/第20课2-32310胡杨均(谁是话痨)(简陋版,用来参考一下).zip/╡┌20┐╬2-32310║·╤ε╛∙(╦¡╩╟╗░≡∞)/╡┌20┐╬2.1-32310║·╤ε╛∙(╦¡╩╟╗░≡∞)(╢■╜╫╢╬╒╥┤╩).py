import re
with open('三国.txt','r',encoding='utf-8') as f:
    lines=f.readlines()
    names=['关公','云长','关某']
    say=['曰：','云：','问：','议：']
    include=[]
    ci=0
    zi=0
    for j in names:
        for i in lines:
            if re.search(j,i):
                 include.append(i)
    for j in range(len(say)):
        for k in range(len(names)):
            for i in include:
                r=names[k]+'[^。？！"]{0,10}'+say[j]
                r2=names[k]+'[^。？！"]{0,10}'+say[j]+r'.*?'+'([^"]+)'
                a=re.findall(r,i)
                a2=re.findall(r2,i)
                if a!=[]:
                    ci+=len(a)
                    for l in range(len(a2)):
                        zi+=len(str(a2[l]))
                    print(a)
                    print(a2)
    print(ci,zi)

