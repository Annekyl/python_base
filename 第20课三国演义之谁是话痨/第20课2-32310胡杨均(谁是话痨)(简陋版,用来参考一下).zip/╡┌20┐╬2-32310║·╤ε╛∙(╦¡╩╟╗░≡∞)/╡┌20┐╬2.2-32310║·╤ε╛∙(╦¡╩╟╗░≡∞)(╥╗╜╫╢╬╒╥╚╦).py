import re
with open('三国1.txt','r',encoding='utf-8') as f:
    lines=f.readlines()
    names=['关羽','关','羽','关公','关某']
    say=['曰："','云："','问："','议："']
    include=[]
    ci=0
    for j in names:
        for i in lines:
            if re.search(j,i):
                 include.append(i)
    for j in range(len(say)):
        for k in range(len(names)):
            for i in include:
                r=names[k]+r'[^。？!]{0,10}'+say[j]
                a=re.findall(r,i)
                ci+=len(a)
                if a!=[]:
                    print(a)
    print(ci)
