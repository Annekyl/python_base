import re
def say(x):
    with open('三国.txt','r',encoding='utf-8') as f:
        lines=f.readlines()
        names=x
        say=['曰：','云：','问：','议：']#表示说话的词,可以添加
        ci=0
        zi=0
        for j in range(len(say)):
            for k in range(len(names)):
                for i in lines:
                    r=names[k]+'[^。？！"]{0,10}'+say[j]#更改'10'的大小调整精度,太大太小精度都会降低,默认为10
                    #'[^。？！"]{0,10}'的意思是不含有。？！"而且最多只能有10个字
                    r2=r+r'.*?'+'([^"]+)'
                    a=re.findall(r,i)
                    a2=re.findall(r2,i)
                    if a!=[]:
                        ci+=len(a)
                        for l in range(len(a2)):
                            zi+=len(str(a2[l]))
                        #print(a)#这是显示说话人
                        #print(a2)#这是显示说的话
                        #print(ci,zi)#这是都加起来的数
        print(f'{x}说的次数:',ci,f'{x}说的字数:',zi)
#可自行添加别称,但注意有'关'这种就不用再加'关公'了,因为'关公'已经含有'关'了,容易出现重复
say(['关公','云长'])
say(['玄德'])
say(['操'])
say(['权'])
say(['飞'])
say(['孔明'])
say(['瑜'])

