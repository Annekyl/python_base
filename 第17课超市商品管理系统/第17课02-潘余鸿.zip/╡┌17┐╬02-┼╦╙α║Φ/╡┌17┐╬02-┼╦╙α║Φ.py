#您可以录入条码
import re
import turtle as tt
import random
f=open('good.txt','r',encoding='utf-8')#开，读全部，切开做列表方便用
f1=open('users.txt','a',encoding='utf-8')
a={}#登记字典
e={}#单次销售字典
sell0=[]#储存键的列表
sell2=[]#比较列表
sell1={}#总销售字典
u1={}#用户字典
check0=['a1A1','b2B2','c3C3','d4D4','e5E5']
price=0
price1=0
oo=1
u=1
num1=1
def sign_up():
        user1=input('您要注册的用户名是：')
        user2=input('您要使用的密码是：')
        user3=input('请重复您的密码：')
        if user3==user2:
            user1=user1+'\n'
            f1.write(user1)
            user3=user3+'\n'
            f1.write(user3)
            f1.write('\n')
            f1.close()
            
            print("用户注册成功！")
        else:
            print("两次密码不同，请您重新注册")
def sign_in():
    global u
    new1()
    user1=input('您要登录的用户是(账号密码写在上方)：')
    if user1 in u1:
            user3=input('您的密码是：')
            zz=random.randint(0,4)
            yzm=check0[zz]
            print("验证码:",yzm)
            gg=input('请输入您看到的验证码：')
            if user3==u1[user1] and gg==yzm:
                    print("\n登录成功!")
                    u=0
            else:
                    print("\n密码或验证码错误，小子!")
                    
    else:
            print("\n账号错误，小子!")    
    
def new():#把a变为一个保持更新，便于查询的字典
    a.clear()
    global b
    f=open('good.txt','r',encoding='utf-8')
    f.seek(0)
    ls=f.read()
    b=ls.split('\n')
    x=(len(b)-1)
    for i in range(int(x/3)):
        a[b[i*3]]=[b[i*3+1],int(b[i*3+2])]
    f.close()
def new1():#把u1变为一个保持更新，便于查询的字典
    global d
    f1=open('users.txt','r',encoding='utf-8')
    f1.seek(0)
    ls1=f1.read()
    d=ls1.split('\n')
    x=(len(d)-1)
    for i in range(int(x/2)):
        u1[d[i*2]]=d[i*2+1]
    f1.close()
    print(u1)
#--------------------------------
def outit():#查询
    print("目前已录入：",a)
    t1=input('\n条码号：')
    if t1 in a:
        p1=a[t1][0]
        q1=a[t1][1]
        print("商品:",p1)
        print("价格:",q1)
    else:
        print("\n此商品未被录入系统，请先录入")
    
def init():#输入,最特殊的
    new()
    t2=input('\n条码号：')
    t3=input('登记商品名：')
    t4=input('登记价格(请不要将多个商品设为同一价格)：')
    f=open('good.txt','a',encoding='utf-8')
    stu2=t2
    stu2=stu2+'\n'
    f.write(stu2)
    stu3=t3
    stu3=stu3+'\n'
    f.write(stu3)
    stu4=t4
    stu4=stu4+'\n'
    f.write(stu4)
    f.close()
    new()
def delete(string):  
    with open('good.txt', 'r',encoding='utf-8') as file:  
        content = file.read()   
    content = re.sub(f'{string}\n', '', content, flags=re.IGNORECASE)    
    with open('good.txt', 'w',encoding='utf-8') as file:  
        file.write(content)
def trans():#修改
    t2=input('\n您要修改的商品条码号：')
    new()
    if t2 in a:
        p = b.index(t2)#索引  
        print(p)
        t3=b[p+1]
        t4=b[p+2] 
        delete(t2)
        delete(t3)
        delete(t4)   
        new()   
        t3=input('将商品名修改为：')
        t4=input('将价格修改为(请不要将多个商品设为同一价格)：')
        f=open('good.txt','a',encoding='utf-8')
        stu2=t2
        stu2=stu2+'\n'
        f.write(stu2)
        stu3=t3
        stu3=stu3+'\n'
        f.write(stu3)
        stu4=t4
        stu4=stu4+'\n'
        f.write(stu4)
        f.close()
        new()
    else:
        print("\n请先录入商品!")
def shan():#删除
    t2=input('\n要删除的条码号：')
    new()
    if t2 in a:    
        p = b.index(t2)#索引  
        print(p)
        t3=b[p+1]
        t4=b[p+2] 
        delete(t2)
        delete(t3)
        delete(t4)   
        new()
    else:
        print("\n该商品并未被录入，无需删除")
def shou():#收银单个商品
    global oo
    t1=input('\n条码号：')
    if t1 in sell0:
        pass
    else:
        sell0.append(t1)
        print(sell0)
    if t1 in e:
        e[t1]=[a[t1][0],a[t1][1],e[t1][2]+1,a[t1][1]*(e[t1][2]+1)]
        sell1[t1]=[a[t1][0],sell1[t1][1]+1]
    else:
        num=1
        e[t1]=[a[t1][0],a[t1][1],num,a[t1][1]*num]
        if t1 in sell1:
            sell1[t1]=[a[t1][0],sell1[t1][1]+1]          
        else:
            sell1[t1]=[a[t1][0],num]
    oo=int(input('您要：1.继续收银 2.结束收银'))
def shouyin():#收银------------------------------------------------------
    new()
    tt.pu()
    tt.goto(-115,250)
    tt.write("2023级编程超市",font=('宋体',20))
            
    global oo
    global price
    global price1
    while(oo==1):
        shou()
        if (oo==2):
            print("\n\n您的小票如下：")
            g=0
            for i in e:
                g+=1
                print("{}   商品名:{}   单价{}元   数量{}   总价{}元\n".format(g,e[i][0],e[i][1],e[i][2],int(e[i][3])))
                tt.goto(-205,235-g*20)
                tt.write("{}   商品名:{}   单价:{}元   数量:{}  总价:{}元\n".format(g,e[i][0],e[i][1],e[i][2],int(e[i][3])),font=('宋体',12))
                price+=int(e[i][3])
            print("\n合计金额：        %2.f元"%price)
            tt.goto(-215,80-g*20+45)
            tt.write("\n合计金额：%2.f元"%price,font=('宋体',15))

            tt.goto(-215,80-g*20+15)
            tt.write("谢谢惠顾，欢迎下次光临！",font=('宋体',20))
            

            tt.goto(-215,280)
            tt.pd()
            for k in range(2):
                tt.fd(430)
                tt.rt(90)
                tt.fd(200+g*20)
                tt.rt(90)
            
            break
    price1+=price
    oo=1
    #tt.done()
    

def sor():
    sell2=sell0
    print(sell2)
    for j in range(len(sell2)-1):
        for i in range(len(sell2)-(j+1)):
            if(sell1[sell2[j]][1]<sell1[sell2[i+1+j]][1]):#比较条件
                sell2[j],sell2[i+1+j]=sell2[i+1+j],sell2[j]
    for i in range(len(sell2)):
        print("当前销量第{}的商品为{}，共销售{}件".format(i+1,sell1[sell2[i]][0],sell1[sell2[i]][1]))
def check():
        global u
        print("欢迎您使用收银系统！")
        while(u==1):
                choice=int(input('\n您选择：1.登录账户 2.注册账户'))
                if choice==1:
                        sign_in()
                if choice==2:
                        sign_up()
                        
                
                
                
#--------------主程序------------------
new()
check()
while(u==0):
    t=int(input('\n选择您要使用的功能：1.录入 2.扫出 3.删除 4.修改 5.收银 6.分析当前销售情况 7.退出'))
    if t==1:
        init()
    if t==2:
        outit()
    if t==3:
        shan()
    if t==4:
        trans()
    if t==5:
        tt.clear()
        shouyin()
        e={}
        price=0
    if t==6:
        print("\n今日总销售额为：{}".format(price1))
        sor()
    if t==7:
        break

        

    
