# -*- coding:utf-8 -*-
"""
作者：潘余鸿
日期：2023年11月29日
"""
import pygame
import sys
import random
import setting
import time
import datetime as dt

# pygame初始化
pygame.init()


class Window:  # 游戏窗口背景
    def __init__(self):
        pygame.display.set_caption("Mirror")  # 标题设定
        self.game_window = pygame.display.set_mode((1200, 800))  # 背景屏幕大小设定
        self.image1 = pygame.image.load("images/0.png")  # 载入左侧背景图片1
        # self.image2 = pygame.image.load("images/wall.png")  # 载入右侧背景图片2

    def load(self):  # 游戏窗口图片装入
        self.game_window.blit(self.image1, (0, 0))  # 装入背景图1
        # self.game_window.blit(self.image2, (600, 0))  # 装入背景图2


class Ship(pygame.sprite.Sprite):
    def __init__(self, image):
        super().__init__()
        image_load = pygame.image.load(image)
        self.original_width, self.original_height = image_load.get_rect().size
        image_load = pygame.transform.rotozoom(image_load, 180, 0.35)  # 原图有点大，按0.8缩放
        self.image = image_load.convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = 600  # 随机生成敌人的x坐标
        self.rect.y = 250  # 初始位置在屏幕下方一定范围
        self.speed = random.randint(3, 3)
        self.is_UP = False
        self.is_DOWN = False
        self.is_LEFT = False
        self.is_RIGHT = False
        self.original_x = self.rect.x
        self.original_y = self.rect.y

    # 飞船移动
    def update(self):
        hit1 = pygame.sprite.spritecollide(self, game1.walls, False)
        #print(self.rect.x, self.rect.y)
        if self.rect.y < -6:
            self.rect.y = 797
        if self.rect.y > 800:
            self.rect.y = 3
        if self.rect.x < -18:
            self.rect.x = 1190
        if self.rect.x > 1195:
            self.rect.x = -15
        if self.is_UP:
            self.rect.y -= self.speed
        if self.is_DOWN:
            self.rect.y += self.speed
        if self.is_LEFT:
            self.rect.x -= self.speed
        if self.is_RIGHT:
            self.rect.x += self.speed
        self.handle_collision(hit1)

    def handle_collision(self, hit1):
        if hit1:
            # 处理碰撞响应
            if self.original_x - self.rect.x > 0:
                self.rect.x += 10
            elif self.original_x - self.rect.x < 0:
                self.rect.x -= 10
            if self.original_y - self.rect.y > 0:
                self.rect.y += 10
            elif self.original_y - self.rect.y < 0:
                self.rect.y -= 10
                # 保存当前位置为原始位置
            self.original_x = self.rect.x
            self.original_y = self.rect.y


class Wall(pygame.sprite.Sprite):
    def __init__(self, image, locate, area):
        super().__init__()

        image_load = pygame.image.load(image)
        self.rect = pygame.Rect(0, 0, area[0], area[1])
        image_load = image_load.subsurface(self.rect)
        image_load = pygame.transform.rotozoom(image_load, 0, 0.5)  # 原图有点大，按0.8缩放
        self.image = image_load.convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = locate[0]
        self.rect.y = locate[1]
        self.speed = random.randint(1, 5)

    def update(self):
        pass


class Ghost(pygame.sprite.Sprite):
    def __init__(self, image, locate):
        super().__init__()
        image_load = pygame.image.load(image)
        self.original_width, self.original_height = image_load.get_rect().size
        image_load = pygame.transform.rotozoom(image_load, 0, 0.35)  # 原图有点大，按0.8缩放
        self.image = image_load.convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = locate[0]
        self.rect.y = locate[1]
        self.speed = random.randint(1, 5)
        self.original_x = self.rect.x
        self.original_y = self.rect.y

    def update(self):
        X = game1.ship1.rect.x - self.rect.x
        Y = game1.ship1.rect.y - self.rect.y

        if abs(X) < 400 and abs(Y) < 300:
            if self.rect.y < -6:
                self.rect.y = 797
            if self.rect.y > 800:
                self.rect.y = 3
            if self.rect.x < -18:
                self.rect.x = 1190
            if self.rect.x > 1195:
                self.rect.x = -15
            hit2 = pygame.sprite.spritecollide(self, game1.walls, False)
            if X > 0:
                self.rect.x += 2
            if X < 0:
                self.rect.x -= 2
            if abs(X) < 20:
                if Y > 0:
                    self.rect.y += 2
                if Y < 0:
                    self.rect.y -= 2
            self.handle_collision(hit2)

    def handle_collision(self, hit2):
        if hit2:
            # 处理碰撞响应
            if self.original_x - self.rect.x > 0:
                self.rect.x += 10
            elif self.original_x - self.rect.x < 0:
                self.rect.x -= 10
            if self.original_y - self.rect.y > 0:
                self.rect.y += 10
            elif self.original_y - self.rect.y < 0:
                self.rect.y -= 10
                # 保存当前位置为原始位置
            keys = pygame.key.get_pressed()  # 获取按键状态
            if keys[pygame.K_LEFT]:  # 如果向左移动，更新ghosts精灵的位置
                self.rect.x -= self.speed
            if keys[pygame.K_RIGHT]:  # 如果向右移动，更新ghosts精灵的位置
                self.rect.x += self.speed
            if keys[pygame.K_UP]:  # 如果向上移动，更新ghosts精灵的位置
                self.rect.y -= self.speed
            if keys[pygame.K_DOWN]:  # 如果向下移动，更新ghosts精灵的位置
                self.rect.y += self.speed
            self.original_x = self.rect.x
            self.original_y = self.rect.y


class Pulse(pygame.sprite.Sprite):
    def __init__(self, image, walls, min_x, min_y, max_x, max_y):
        super().__init__()
        self.walls = walls
        image_load = pygame.image.load(image)
        image_load = pygame.transform.rotozoom(image_load, 0, 0.4)
        self.image = image_load.convert_alpha()

        # 生成随机的初始位置，确保不与walls精灵组重叠且在指定范围内
        self.rect = self.image.get_rect()
        while True:
            self.rect.x = random.randint(min_x, max_x)  # 设置x轴范围
            self.rect.y = random.randint(min_y, max_y)  # 设置y轴范围
            if not any(wall.rect.collidepoint(self.rect.center) for wall in
                       self.walls) and self.rect.x >= min_x and self.rect.x <= max_x and self.rect.y >= min_y and self.rect.y <= max_y:
                break  # 如果位置在范围内且不与walls精灵组重叠，则停止循环

    def update(self):
        global  score
        hit3 = pygame.sprite.spritecollide(self, game1.ships, False)
        if hit3:
            score+=1
            game1.pulses.remove(self)
        pass

class Word(object):
    # 获取准确时间计算秒数
    global tm
    font = pygame.font.Font('freesansbold.ttf', 32)
    first_time = dt.datetime.now()

    def __init__(self, text, x, y):
        self.txt_font = pygame.font.SysFont(None, 32)
        self.txt_image = self.txt_font.render(text, True, (0, 0, 0), (255, 255, 255))
        self.txt_rect = self.txt_image.get_rect()
        self.txt_rect.x = x
        self.txt_rect.y = y
        self.font = pygame.font.Font('freesansbold.ttf', 32)

    # 显示血量
    @classmethod
    def __showhitpoint__(cls, screen):
        global hitpoint
        text = f"SCORE={score}"
        hitpoint_render = Word.font.render(text, True, (255, 0, 0))
        screen.blit(hitpoint_render, (520, 50))  # 保持渲染

    # 显示时间
    @classmethod
    def __showtime__(cls, screen):
        tm = dt.datetime.today()
        time_difference = tm - Word.first_time
        time_difference_seconds = time_difference.total_seconds()  # 把单位换成秒
        time_difference_formatted = "{:.1f}".format(time_difference_seconds)  # 精确到0.01s
        text2 = f"TIME={time_difference_formatted}S"
        hitpoint_render = Word.font.render(text2, True, (0, 255, 0))
        screen.blit(hitpoint_render, (520, 15))  # 保持渲染

    @classmethod
    def __showend1__(cls, screen):
        text = f"WIN!!!"
        font = pygame.font.Font('freesansbold.ttf', 50)
        hitpoint_render = font.render(text, True, (0, 255, 0))
        screen.blit(hitpoint_render, (545, 360))  # 保持渲染

    @classmethod
    def __showend2__(cls, screen):
        text = f"lose!!!"
        font = pygame.font.Font('freesansbold.ttf', 50)
        hitpoint_render = font.render(text, True, (255, 0, 0))
        screen.blit(hitpoint_render, (540, 360))  # 保持渲染


class Game:
    global score
    score = 0

    def __init__(self):

        self.clock = pygame.time.Clock()
        self.window = Window()
        self.ship1 = Ship("images/pacman.png")
        self.ships = pygame.sprite.Group()
        self.ships.add(self.ship1)

        self.walls = pygame.sprite.Group()
        for i in range(len(setting.areas)):
            wall = Wall("images/00"
                        ".png", setting.locations[i], setting.areas[i])
            self.walls.add(wall)

        self.ghosts = pygame.sprite.Group()
        for i in range(4):
            # for i in range(len(setting.G_colors)):
            ghost = Ghost(setting.G_colors[i], setting.G_locations[i])
            self.ghosts.add(ghost)

        self.pulses = pygame.sprite.Group()

        for i in range(40):
            pulse = Pulse("images/food.png",self.walls,70,70,1100,650)
            self.pulses.add(pulse)

        self.play_music("星际穿越BGM.mp3")  # 播放背景音乐

        self.fps = 30
        self.running = True
        self.screen = pygame.display.set_mode((1200, 800))
        pygame.display.set_caption('pygame版游戏')

    def load(self):
        window1 = Window()  # 创建窗口对象
        self.window = window1  # 更新窗口对象属性

    def handle_events(self):
        for event in pygame.event.get():  # 处理事件
            if event.type == pygame.QUIT:  # 找出关闭窗口的情况
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    self.ship1.is_UP = True
                elif event.key == pygame.K_DOWN:
                    self.ship1.is_DOWN = True
                elif event.key == pygame.K_LEFT:
                    self.ship1.is_LEFT = True
                elif event.key == pygame.K_RIGHT:
                    self.ship1.is_RIGHT = True
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_UP:
                    self.ship1.is_UP = False
                elif event.key == pygame.K_DOWN:
                    self.ship1.is_DOWN = False
                elif event.key == pygame.K_LEFT:
                    self.ship1.is_LEFT = False
                elif event.key == pygame.K_RIGHT:
                    self.ship1.is_RIGHT = False

    def play_music(self, music_file):  # 播放背景音乐方法
        pygame.mixer.music.load(music_file)  # 加载音乐文件
        pygame.mixer.music.play(-1)  # 循环播放音乐文件，参数-1表示循环播放

    def run(self):
        while self.running:
            hit3 = pygame.sprite.spritecollide(self.ship1, self.ghosts, False)
            self.window.load()
            self.handle_events()

            self.walls.update()
            self.walls.draw(self.screen)

            self.ghosts.update()
            self.ghosts.draw(self.screen)

            self.ships.update()
            self.ships.draw(self.screen)

            self.pulses.update()
            self.pulses.draw(self.screen)

            Word.__showtime__(self.screen)
            Word.__showhitpoint__(self.screen)
            pygame.display.flip()  # 刷新屏幕显示内容
            if len(self.pulses)==0:
                Word.__showend1__(self.screen)
                pygame.display.flip()
                time.sleep(3)
                self.running = False
            if hit3:
                print("GG!")
                Word.__showend2__(self.screen)
                pygame.display.flip()
                time.sleep(3)
                self.running = False

            pygame.display.flip()  # 刷新屏幕显示内容
            self.clock.tick(60)  # 设置帧率为60帧每秒
            pygame.time.set_timer(pygame.USEREVENT + 1, 1000 // 10)  # 第一个精灵组每秒30帧
            pygame.time.set_timer(pygame.USEREVENT + 2, 1000 // 30)  # 第二个精灵组每秒60帧
            pygame.time.set_timer(pygame.USEREVENT + 3, 1000 // 60)  # 第一个精灵组每秒30帧
            pygame.time.set_timer(pygame.USEREVENT + 4, 1000 // 60)  # 第一个精灵组每秒30帧


# 创建游戏对象
game1 = Game()

# 游戏运行
game1.run()
