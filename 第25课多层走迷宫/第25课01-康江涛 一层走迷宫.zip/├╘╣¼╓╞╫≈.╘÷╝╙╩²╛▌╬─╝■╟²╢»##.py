##数据文件中的1是障碍 0是道路 通过修改数据文件可以实现关卡的转换

import pygame
import sys
import data_read as dr
contents=dr.greet()
width = 800
height = 600

class Ball(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.ball_radius = 10
        self.ball_color = (255, 255, 255)

        self.image = pygame.Surface((self.ball_radius * 2, self.ball_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(self.image, self.ball_color, (self.ball_radius, self.ball_radius), self.ball_radius)
        self.rect = self.image.get_rect(center=(width, height)) #创建小球这个精灵

    def update(self):
        move = pygame.mouse.get_pos()
        self.rect.x = move[0]
        self.rect.y = move[1] #通过鼠标更新位置

class Block(pygame.sprite.Sprite):
    def __init__(self, x, y, maze_data):
        super().__init__()
        self.x = x
        self.y = y
        self.maze_size = 50
        self.maze_width = self.maze_size
        self.maze_height = self.maze_size
        self.maze1_color = (0, 255, 255)

        self.image = pygame.Surface((self.maze_width, self.maze_height), pygame.SRCALPHA)
        self.a = self.x * self.maze_size
        self.b = self.y * self.maze_size
        if maze_data[self.x][self.y] == 1:
            pygame.draw.rect(self.image, self.maze1_color, (0, 0, self.maze_size, self.maze_size)) # 这个就是相对于左上角的位置

        self.rect = self.image.get_rect(topleft=(self.a, self.b)) # 相对于左上角迷宫的位置这样可以方便点

class Road(pygame.sprite.Sprite):
    def __init__(self, x, y, maze_data):
        super().__init__()
        self.x = x
        self.y = y
        self.maze_size = 50
        self.maze_width = self.maze_size
        self.maze_height = self.maze_size
        self.maze2_color = (255, 0, 255)

        self.image = pygame.Surface((self.maze_width, self.maze_height), pygame.SRCALPHA)
        self.a = self.x * self.maze_size
        self.b = self.y * self.maze_size

        if maze_data[self.x][self.y] == 0:
            pygame.draw.rect(self.image, self.maze2_color, (0, 0, self.maze_size, self.maze_size))

        self.rect = self.image.get_rect(topleft=(self.a, self.b))


class Run(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        self.all_sprites = pygame.sprite.Group()
        self.block_group = pygame.sprite.Group()
        self.road_group = pygame.sprite.Group()
        self.running = True
       
        maze_data=contents

        for i in range(len(maze_data)):
            for j in range(len(maze_data[0])):
                if maze_data[i][j] == 1:
                    block = Block(i, j, maze_data)
                    self.block_group.add(block)
                    self.all_sprites.add(block)
                elif maze_data[i][j] == 0:
                    road = Road(i, j, maze_data)
                    self.road_group.add(road)
                    self.all_sprites.add(road)

        self.ball = Ball()
        self.all_sprites.add(self.ball)

        self.clock = pygame.time.Clock()

    def run(self):
        pygame.init()
        
        window = pygame.display.set_mode((width, height))
        pygame.display.set_caption('labyrinth')

        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            hit = pygame.sprite.spritecollide(self.ball, self.block_group, False)
            hit2 = pygame.sprite.spritecollide(self.ball, self.road_group, False)
            if hit:
                if not hit2:
                    print('Game Over')
                    self.running = False

            self.all_sprites.update()
            window.fill((0, 0, 0))


            self.all_sprites.draw(window)
            pygame.display.flip()
            self.clock.tick(60)

        self.quit()

    def quit(self):
        pygame.quit()
        sys.exit()

a = Run()
a.run()


            











