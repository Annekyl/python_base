import ast

def greet():
    def get_coach_data():
        with open('E:\\python学习实验室\\第25课\\数据文件.txt','r+',encoding='utf-8') as f:
            lines = f.readlines()
        return lines

    content=get_coach_data()
    contents=[]
    for i in content:
        i=i.strip()
        contents.append(i)
    contents=''.join(contents)
    contents=ast.literal_eval(contents)

    return contents



