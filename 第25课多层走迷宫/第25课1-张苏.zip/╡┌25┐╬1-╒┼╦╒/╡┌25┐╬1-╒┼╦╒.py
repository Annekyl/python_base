
import pygame
import sys
import random

WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
pygame.init()
window = pygame.display.set_mode((1200, 800))
pygame.display.set_caption("一号迷宫")


class MySprite(pygame.sprite.Sprite):
    def __init__(self, color, width, height, x, y):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)





    def shang(self):
        self.rect.y -= 10

    def xia(self):
        self.rect.y += 10

    def zuo(self):
        self.rect.x -= 10

    def you(self):
        self.rect.x += 10


class Www(pygame.sprite.Sprite):
    def __init__(self, color, width, height, x, y):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

class Game:
    def __init__(self):
        self.a = MySprite(BLUE, 10, 10, 100, 740)
        sl = Www(GREEN, 20, 20, 1100, 150)
        b = Www(RED, 1200, 50, 600, 5)
        c = Www(RED, 1200, 50, 600, 795)
        d = Www(RED, 50, 800, 5, 400)
        e = Www(RED, 50, 800, 1195, 400)
        mmm1 = random.randint(800, 1000)
        mm1 = random.randint(600, 1200)
        c1 = Www(RED, mmm1, 10, mm1, 100)
        mmm2 = random.randint(100, 1000)
        mm2 = random.randint(300, 900)
        c2 = Www(RED, mmm2, 10, mm2, 200)
        mmm3 = random.randint(100, 1000)
        mm3 = random.randint(300, 900)
        c3 = Www(RED, mmm3, 10, mm3, 300)
        mmm4 = random.randint(300, 1000)
        mm4 = random.randint(300, 900)
        c4 = Www(RED, mmm4, 10, mm4, 400)
        mmm5 = random.randint(800, 1000)
        mm5 = random.randint(700, 900)
        c5 = Www(RED, mmm5, 10, mm5, 500)
        mmm6 = random.randint(100, 1000)
        mm6 = random.randint(300, 900)
        c6 = Www(RED, mmm6, 10, mm6, 600)
        mmm7 = random.randint(800, 1000)
        mm7 = random.randint(300, 900)
        c7 = Www(RED, mmm7, 10, mm7, 700)

        nnn1 = random.randint(100, 500)
        nn1 = random.randint(0, 400)
        k1 = Www(RED, 10, nnn1, 100, nn1)
        '''
        nnn2 = random.randint(100, 400)
        nn2 = random.randint(200, 300)
        k2 = Www(RED, 10, nnn2, 200, nn2)'''
        nnn3 = random.randint(100, 300)
        nn3 = random.randint(0, 500)
        k3 = Www(RED, 10, nnn3, 300, nn3)
        '''
        nnn4 = random.randint(300, 400)
        nn4 = random.randint(200, 400)
        k4 = Www(RED, 10, nnn4, 400, nn4)'''
        nnn5 = random.randint(100, 300)
        nn5 = random.randint(300, 400)
        k5 = Www(RED, 10, nnn5, 500, nn5)
        '''
        nnn6 = random.randint(100, 500)
        nn6 = random.randint(400, 500)
        k6 = Www(RED, 10, nnn6, 600, nn6)
        '''
        nnn7 = random.randint(100, 400)
        nn7 = random.randint(0, 600)
        k7 = Www(RED, 10, nnn7, 700, nn7)
        '''
        nnn8 = random.randint(200, 300)
        nn8 = random.randint(400, 500)
        k8 = Www(RED, 10, nnn8, 800, nn8)
        nnn9 = random.randint(100, 500)
        nn9 = random.randint(400, 500)
        k9 = Www(RED, 10, nnn9, 900, nn9)'''
        '''
        nnn10 = random.randint(0, 400)
        nn10 = random.randint(300, 600)
        k10 = Www(RED, 10, nnn10, 1000, nn10)'''
        my_group = pygame.sprite.Group()  # 创建一个精灵组
        my_group1 = pygame.sprite.Group()
        my_group2 = pygame.sprite.Group()
        my_group1.add(self.a)
        my_group2.add(sl)
        my_group.add(b)
        my_group.add(c)
        my_group.add(d)
        my_group.add(e)

        my_group.add(c1)
        my_group.add(c2)
        my_group.add(c3)
        my_group.add(c4)
        my_group.add(c5)
        my_group.add(c6)
        my_group.add(c7)

        my_group.add(k1)
        #my_group.add(k2)
        my_group.add(k3)
        #my_group.add(k4)
        my_group.add(k5)
        #my_group.add(k6)
        my_group.add(k7)
        #my_group.add(k8)
        #my_group.add(k9)
        #my_group.add(k10)

        running = True
        while running:
            window.fill(WHITE)
            collided_sprites = pygame.sprite.spritecollide(self.a, my_group, False)
            sll = pygame.sprite.spritecollide(self.a, my_group2, False)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_w:
                        if collided_sprites:
                            exit()
                        elif sll:
                            print("胜利")
                        else:
                            a.shang()
                    elif event.key == pygame.K_s:
                        if collided_sprites:
                            exit()
                        elif sll:
                            print("胜利")
                        else:
                            a.xia()
                    elif event.key == pygame.K_a:
                        if collided_sprites:
                            exit()
                        elif sll:
                            print("胜利")
                        else:
                            a.zuo()
                    elif event.key == pygame.K_d:
                        if collided_sprites:
                            exit()
                        elif sll:
                            print("胜利")
                        else:
                            a.you()
            my_group1.update()  # 更新精灵组中所有精灵的状态
            my_group1.draw(window)
            my_group2.update()  # 更新精灵组中所有精灵的状态
            my_group2.draw(window)
            my_group.update()  # 更新精灵组中所有精灵的状态
            my_group.draw(window)
            pygame.display.flip()
        pygame.quit()
        sys.exit()

game = Game()