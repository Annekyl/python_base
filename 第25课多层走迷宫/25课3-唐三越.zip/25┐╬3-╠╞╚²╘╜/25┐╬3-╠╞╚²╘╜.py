import pygame
import sys
import time
import os
pygame.init()
'''ball 和 ball.rect 的主要区别在于，ball 是一个游戏对象，
而 ball.rect 是描述这个游戏对象位置和大小的矩形区域
Rect 对象常常用于碰撞检测和图形渲染'''
class Constants:#初始数据
    WIDTH = 800
    HEIGHT = 600
    BALL_SIZE = 20
    BALL_COLOR = (102, 247, 250)
    BG_COLOR = (147, 158, 67)
    WALL_COLOR = (93, 97, 84)
    #开始和结束的标识
    START_COLOR = (0, 255, 0)  # Green
    END_COLOR = (255, 0, 0)  # Red
    FONT = pygame.font.Font("STHUPO.ttf", 30)#可换字体
class Ball:
    def __init__(self, x, y):#每次调用类时自动执行,初始化新创建的对象
        self.rect = pygame.Rect(x, y, Constants.BALL_SIZE, Constants.BALL_SIZE)
# rect 表示矩形区域:四个参数:     左上角(0,0),宽度,高度
    def move_ip(self, x, y):
        self.rect.move_ip(x, y)#(x, y):偏移量,且move_ip不是返回一个新的 Rect 对象
    def draw(self, screen):
        pygame.draw.rect(screen, Constants.BALL_COLOR, self.rect)
class Block:
    def __init__(self, x, y, color):
        self.rect = pygame.Rect(x, y, Constants.BALL_SIZE, Constants.BALL_SIZE)
        self.color = color
    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect)
class Wall:
    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
    def draw(self, screen):
        pygame.draw.rect(screen, Constants.WALL_COLOR, self.rect)
class Game:
    def __init__(self,level=1):#level=1在没提供参数时使用
        self.level = level
        self.screen = pygame.display.set_mode((Constants.WIDTH, Constants.HEIGHT))
        pygame.display.set_caption('走迷宫')
        self.clock = pygame.time.Clock()
        self.start_ticks = pygame.time.get_ticks()
        self.ball = Ball(23, 300)#起始位置
        self.start_block = Block(0, Constants.HEIGHT // 2, Constants.START_COLOR)
        self.end_block = Block(Constants.WIDTH - Constants.BALL_SIZE, Constants.HEIGHT // 2, Constants.END_COLOR)
        self.walls = [
            Wall(0, 0, Constants.WIDTH, 10),  #顶部
            Wall(0, 0, 10, Constants.HEIGHT),  #左
            Wall(0, Constants.HEIGHT - 10, Constants.WIDTH, 10),  #底部
            Wall(Constants.WIDTH - 10, 0, 10, Constants.HEIGHT),  # 右
        ]#默认四周的墙壁
        with open(f'迷宫数据{self.level}.txt', 'r', encoding='utf-8') as f:
            for line in f:
                values = line.split(',')
                if not line[0].isdigit():
                    continue
                New_X = int(values[0].strip())
                New_Y = int(values[1].strip())
                self.walls.append(Wall(New_X, New_Y, 20, Constants.HEIGHT - 50))
    def check_collision(self):
        for wall in self.walls:#检测两个矩形（Rect 对象）是否有交集
            if self.ball.rect.colliderect(wall.rect):
                return True
        return False
    def check_end(self):
        if self.ball.rect.colliderect(self.end_block.rect): 
            num_of_levels = len([name for name in os.listdir() if name.endswith('.txt')])
            if self.level == num_of_levels:
                self.game_over2()
            else:
                self.level += 1
                self.__init__(self.level)
        return False
    def game_over1(self):
        text = Constants.FONT.render('遗憾失败,再接再厉', True, (0, 0, 0))
        self.screen.blit(text, (Constants.WIDTH // 2 - text.get_width() // 2, Constants.HEIGHT // 2 - text.get_height() // 2))#自适应
        pygame.display.flip()
        time.sleep(2)
        pygame.quit()
        sys.exit()
    def game_over2(self):
        text = Constants.FONT.render('你赢了,打败全球99%的玩家', True, (0, 0, 0))
        self.screen.blit(text, (Constants.WIDTH // 2 - text.get_width() // 2, Constants.HEIGHT // 2 - text.get_height() // 2))#自适应
        pygame.display.flip()
        time.sleep(2)
        pygame.quit()
        sys.exit()
    def draw_timer(self):
        seconds = (pygame.time.get_ticks() - self.start_ticks) / 1000  # calculate how many seconds
        timer_text = Constants.FONT.render('Time: ' + str(int(seconds)), True, (0, 0, 0))
        self.screen.blit(timer_text, (10, 10))
    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP]:
                self.ball.move_ip(0, -2)
            if keys[pygame.K_DOWN]:
                self.ball.move_ip(0, 2)
            if keys[pygame.K_LEFT]:
                self.ball.move_ip(-2, 0)
            if keys[pygame.K_RIGHT]:
                self.ball.move_ip(2, 0)
             #结束判断
            if self.check_collision():
                self.game_over1()
            if self.check_end():
                self.game_over2()
            self.screen.fill(Constants.BG_COLOR)
            self.start_block.draw(self.screen)
            self.end_block.draw(self.screen)
            for wall in self.walls:
                wall.draw(self.screen)#Wall()类里面的draw()方法
            self.ball.draw(self.screen)
            self.draw_timer()
            pygame.display.flip()#翻转显示

            self.clock.tick(60)#帧率
if __name__ == "__main__":
    game = Game()
    game.run()
