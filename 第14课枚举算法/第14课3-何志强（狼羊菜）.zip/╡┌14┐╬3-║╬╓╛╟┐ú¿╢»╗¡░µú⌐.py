import turtle

def move(tu,x,y,seth,fd):
    turtle.register_shape(tu)
    t = turtle.Turtle()
    t.shape(tu)
    t.up()
    turtle.tracer(0)
    t.goto(x,y)
    turtle.tracer(1)
    t.seth(seth)
    t.fd(fd)
def move2(tu,x,y):
    turtle.register_shape(tu)
    t = turtle.Turtle()
    t.shape(tu)
    t.up()
    turtle.tracer(0)
    t.goto(x, y)
    turtle.tracer(1)
def move1(x,x1,x2,x3,list1,list2):
    print(f"把{x1}从{x2}移到{x3}")
    i=list1.index(x)
    del list1[i]
    list2.append(x)
a = 2   # 羊
b = -1  # 狼
c = -1  # 菜
M=[a,b,c]
F=['羊.gif', '狼.gif', '菜.gif']
N=[]



for j in range(4):
    m=sum(M)
    if m == 0 or m == 2:
        move1(a,' 羊 ',' M岸 ',' N岸 ',M,N)
        print(M,N)
        # move2('羊.gif', -200, 100)
        move('羊.gif', -200, 100, 0, 400)
        turtle.ht()
    elif m == -2:
        move1(b, ' 狼 ',' M岸 ',' N岸 ', M, N)
        print(M, N)
        # move2('狼.gif', -200, 300)
        move('狼.gif', -200, 300, 0, 400)
        turtle.ht()
    elif m == 1:
        move1(c,' 菜 ', ' M岸 ',' N岸 ', M, N)
        print(M, N)
        # move2('菜.gif', -200, 200)
        move('菜.gif', -200, 200, 0, 400)
        turtle.ht()
    else:
        print('false')
    n=sum(N)
    if n == 1:
        move1(a, ' 羊 ', ' N岸 ',' M岸 ', N, M)
        print(M, N)
        move('羊.gif', 200, 100, 180, 400)
        turtle.ht()
turtle.done()
