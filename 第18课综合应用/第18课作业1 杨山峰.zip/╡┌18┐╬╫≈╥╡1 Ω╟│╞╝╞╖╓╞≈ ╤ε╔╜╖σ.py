# -----------------载入库--------------------
import openpyxl
import re

# ------------------准备数据---------------------
total_name = openpyxl.load_workbook(u"QQ群昵称总表.xlsx")
total_score = openpyxl.load_workbook(u"班级名单.xlsx")

name_dl682006 = total_name["导论682006"]
name_dl655694 = total_name["导论655694"]
name_dl655686 = total_name["导论655686"]
name_dl655687 = total_name["导论655687"]

score_dl682006 = total_score["导论682006"]
score_dl655694 = total_score["导论655694"]
score_dl655686 = total_score["导论655686"]
score_dl655687 = total_score["导论655687"]
name_list = [name_dl682006, name_dl655694, name_dl655686, name_dl655687]
score_list = [score_dl682006, score_dl655694, score_dl655686, score_dl655687]
check_all = r'(^[0-9]{10}[\u4E00-\u9FFF]+$)'
check_id = r'([0-9]{10})'
check_name = r'[\u4e00-\u9fa5]+'
# ------------------主程序-------------------------
# 读取数据
for i in range(4):
    sheet1_line = name_list[i]["D"]  # 将数据存放到列表中
    sheet2_line = score_list[i]["B"]
    sheet2_line2 = score_list[i]["C"]
    sheet2_line3 = score_list[i]["F"]
    num1 = len(sheet1_line)  # 数据的总数
    num2 = len(sheet2_line)
    for j in range(num1):  # 遍历全部的数据并进行赋分操作
        result = re.search(check_all, str(sheet1_line[j].value))
        result_id = re.search(check_id, str(sheet1_line[j].value))
        result_name = re.search(check_name, str(sheet1_line[j].value))
        if result is not None:
            result_id = int(result.group()[0:10:1])
            for k in range(num2):
                if sheet2_line[k].value == result_id:
                    score_list[i].cell(k + 1, 6).value = 100
        elif result_name is not None and result_id is not None:
            result_id = int(result_id.group())
            for k in range(num2):
                if sheet2_line[k].value == result_id:
                    score_list[i].cell(k + 1, 6).value = 90
        elif result_name is not None:
            for k in range(num2):
                if sheet2_line2[k].value == result_id:
                    score_list[i].cell(k + 1, 6).value = 80
        elif 1:
            for m in range(num2):
                if score_list[i].cell(m + 1, 6).value != 80 or score_list[i].cell(m + 1, 6).value != 90 or score_list[
                    i].cell(m + 1, 6).value != 100:
                    score_list[i].cell(m + 1, 6).value = 0
total_score.save(u"班级名单.xlsx")
total_name.close()
total_score.close()
