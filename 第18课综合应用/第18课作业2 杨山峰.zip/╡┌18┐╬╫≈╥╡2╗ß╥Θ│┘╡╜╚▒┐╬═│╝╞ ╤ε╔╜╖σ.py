import openpyxl
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

word = [u'01课.xlsx', u'02课.xlsx', u'03课.xlsx']
record = []  # 用于记录缺课数据

f = open("实验室名单.txt", "r", encoding="UTF-8")
total_name = f.readlines()
for i in range(len(total_name)):
    total_name[i] = total_name[i].strip()
f.close()
# print(total_name)

data = openpyxl.load_workbook(word[0])
sheet = data['成员参会概况']
name_line = sheet["A"]  # 参会人
time_line = sheet["B"]  # 入会时间
num = len(name_line)  # 用于控制循环次数
target_time = '2023-09-23 19:31:00'
format_pattern = '%Y-%m-%d %H:%M:%S'
for j in range(10, num + 1):
    attend_time = str(time_line[j - 1].value)
    time1 = datetime.strptime(target_time, format_pattern)
    time2 = datetime.strptime(attend_time, format_pattern)
    if time1 > time2:
        record.append(name_line[j - 1].value + "\n")

f = open("上课情况统计.txt", "a", encoding="UTF-8")
for i in record:
    f.write(i)
f.close()
data = openpyxl.load_workbook(word[1])
sheet = data['成员参会概况']
name_line = sheet["A"]  # 参会人
time_line = sheet["B"]  # 入会时间
num = len(name_line)  # 用于控制循环次数
target_time = '2023-09-23 19:31:00'
format_pattern = '%Y-%m-%d %H:%M:%S'
for j in range(10, num + 1):
    attend_time = str(time_line[j - 1].value)
    time1 = datetime.strptime(target_time, format_pattern)
    time2 = datetime.strptime(attend_time, format_pattern)
    if time1 > time2:
        record.append(name_line[j - 1].value + "\n")

f = open("上课情况统计.txt", "a", encoding="UTF-8")
for i in record:
    f.write(i)
f.close()
data = openpyxl.load_workbook(word[2])
sheet = data['成员参会概况']
name_line = sheet["A"]  # 参会人
time_line = sheet["B"]  # 入会时间
num = len(name_line)  # 用于控制循环次数
target_time = '2023-09-23 19:31:00'
format_pattern = '%Y-%m-%d %H:%M:%S'
for j in range(10, num + 1):
    attend_time = str(time_line[j - 1].value)
    time1 = datetime.strptime(target_time, format_pattern)
    time2 = datetime.strptime(attend_time, format_pattern)
    if time1 > time2:
        record.append(name_line[j - 1].value + "\n")

f = open("上课情况统计.txt", "a", encoding="UTF-8")
for i in record:
    f.write(i)
f.close()
