f1=open('论语解读版本.txt','r',encoding='utf-8')
w1=''
w2=''
w=0
for i in f1:
    line=i.strip()#移除前导和空格
    if line.count('【注释】')==1:  
        w=1
    if line.count('【原文】')==1:
        w=2
    if w==2 and line.count('【注释】')==0 and line.count('【原文】')==0 and len(line)!=0:
        w1+=line+"\n"
for j in w1:
    flag=0
    for w in range(10):
        if j=='('or j==')' or j==str(w):
            flag=1
    if flag==0:
        w2+=j
f1.close()
#输入----------
f2=open('论语精简版.txt','w',encoding='utf-8')
f2.write(w2)
f2.close()

