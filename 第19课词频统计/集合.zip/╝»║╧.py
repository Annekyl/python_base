
list=[1,2,2,3,4,5,5,5,5,5]#去除相同元素
list2=set(list)
print(list2)
'''
set1 = {1, 2, 3}
set2 = {3, 4, 5}

union_set=set1.union(set2)  # 并集
intersection_set=set1.intersection(set2)  # 交集
difference_set=set1.difference(set2)  # 差集
symmetric_difference_set=set1.symmetric_difference(set2)  # 对称差集

union_set=set1|set2  # 并集
intersection_set=set1&set2  # 交集
difference_set=set1-set2  # 差集
symmetric_difference_set=set1^set2  # 对称差集


print(union_set,end=' ')
print(intersection_set,end=' ')
print(difference_set,end=' ')
print(symmetric_difference_set)#输出{1, 2, 3, 4, 5} {3} {1, 2} {1, 2, 4, 5}
'''
