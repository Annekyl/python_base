import jieba
from pyecharts.charts import Bar
from pyecharts.charts import Pie
from pyecharts import options as opts
from pyecharts.charts import Page

D=['政府工作报告2021.txt','政府工作报告2022.txt',]
for w in D :
    f = open( w, 'r',encoding='utf-8')
    content = f.read() #成员名名单
    f.close()
    data = content.split('\n')
    B={}#统计高频词数量
    for i in data:
        k=jieba.lcut(i,cut_all= 1)
        for j in k:
            if len(j)==2:
                B[j]=B.get(j,0)+1
    Q=list(B.items())
    Q.sort(key=lambda x:x[1],reverse= 1)
    C={}
    for p in range(0,10):
        C[Q[p][0]]=int(Q[p][1])
    if w=='政府工作报告2021.txt' :
        list2021l=C
    else:
        list2022l=C
A=[]#相同的词汇
for i in list2021l:
    if i in list2022l:
        A.append(i)
list2022=list(list2022l.items())
list2021=list(list2021l.items())
list221=[list2021[i][0] for i in range(5)]
list222=[list2022[i][0]for i in range(5)]
B=[]#不同的词汇
for i in list221:
    if i not in list222:
        B.append(i)
for i in list222:
    if i not in list221:
        B.append(i)
data1=[list2022l[i] for i in A]
data2=[]
data3=[list2021l[i] for i in A]
for i in B:
    if i in list2022l:
        data2.append(list2022l[i])
    else:
        data2.append(list2021l[i])
pie1 = Pie()
pie2 = Pie()
pie3 = Pie()
pie1.add("饼状图1", [list(z) for z in zip(A  , data1)])
pie1.set_global_opts(title_opts=opts.TitleOpts(title="相同词汇2022"))

pie2.add("饼状图1", [list(z) for z in zip(A , data3)])
pie2.set_global_opts(title_opts=opts.TitleOpts(title="相同词汇2021"))

pie3.add("饼状图1", [list(z) for z in zip(B , data2)])
pie3.set_global_opts(title_opts=opts.TitleOpts(title="不同词汇"))
page = Page()
page.add(pie1, pie2, pie3)
page.render("数据统计.html")
