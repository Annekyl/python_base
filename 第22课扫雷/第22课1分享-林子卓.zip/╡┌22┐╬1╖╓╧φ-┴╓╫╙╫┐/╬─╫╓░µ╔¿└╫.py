import random
class Mine():
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.txt='■'#为对象创建形状
        self.star=False
        self.xing=0
        #self.lianjie=0
        self.zhuangtai=0#标明雷是否被挖防止递归出错
    def wa(self):#定义挖雷的能力
        global l
        if(self.star==True):
            self.txt='雷'
            l=1
        elif(self.xing>0):
            self.txt=' '+str(self.xing)
            l+=1/90
        else:
            self.txt='□'
            l+=1/90
            
#-----------------构建地图--------------------------
def ditu():
    print(' ',end=' ')
    for i in range(10):
        print(i,end=' ')
    print()
    for i in range(10):
        print(i,end='')
        for j in range(10):
            print(ls[i][j].txt,end='')
        print()
        
def touxi():#方便写代码的人观察，方便玩的人作弊
    print(' ',end=' ')
    for i in range(10):
        print(i,end=' ')
    print()
    for i in range(10):
        print(i,end=' ')
        for j in range(10):
            print(ls[i][j].xing,end=' ')
        print()
def lianjie(x,y):#运用递归实现连片的挖开空白
    if(ls[x][y].xing==0 and ls[x][y].zhuangtai==0):
        ls[x][y].zhuangtai=1
        for i in range(3):
            for j in range(3):
                if((0<=x-1+i<=9) and (0<=y-1+j<=9)):
                    ls[x-1+i][y-1+j].wa()
                    x1=x-1+i
                    y1=y-1+j
                    lianjie(x1,y1)
                    
#-----------------生成一个记录对象形状的一个列表----------------
ls=[[0 for i in range(10)]for i in range(10)]
#-------------------将列表中的元素全部命名为类的对象--------------
for i in range(10):
    for j in range(10):
        ls[i][j]=Mine(i,j)#这个记录的过程实际上生成了类的一个仔
#-------------------------种雷----------------------------------
k=0
while(k<10):
    a,b=random.randint(0,9),random.randint(0,9)
    if(ls[a][b].star==True):
        k+=0
    if(ls[a][b].star==False):
        ls[a][b].star=True
        k+=1
        for i in range(3):
            for j in range(3):
                if(0<=a-1+i<=9 and 0<=b-1+j<=9):
                    ls[a-1+i][b-1+j].xing=ls[a-1+i][b-1+j].xing+1
#-----------------------------游戏------------------------------
while(1):
    l=0
    Open=int(input('是否开始游戏(0/1)'))
    if(Open==0):
        ditu()
        while(True):
            if(l==1):
                print("游戏结束")
                break
            a=input("请输入你想要扫开的区域坐标（xy）:")#实现扫雷
            ls[int(a[1])][int(a[0])].wa()
            lianjie(int(a[1]),int(a[0]))
            ditu()
    else:
        break
