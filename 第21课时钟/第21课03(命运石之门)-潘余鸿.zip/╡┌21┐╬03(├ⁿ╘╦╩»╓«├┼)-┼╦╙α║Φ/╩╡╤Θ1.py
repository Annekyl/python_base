import turtle as t
import datetime as dt
import threading
from PIL import Image
tm=dt.datetime.today()
window = t.Screen()
#set3=(int(tm.strftime('%S'))/60)*360
#set2=(int(tm.strftime('%M'))/60)*360
#set1=(int(tm.strftime('%H'))/12)*360
set3=tm.strftime('%S')
set2=tm.strftime('%M')
set1=tm.strftime('%H')
print(set1,set2,set3)
