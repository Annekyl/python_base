import turtle as t
import datetime as dt
import threading

for i in range(11):#登记图像
    t.register_shape('{}.gif'.format(i))
t.register_shape('{}.gif'.format(11))
t.register_shape('{}.gif'.format(-11))
game =t.Screen()
game.title("一切都是石头门的选择!")
game.bgcolor("black")
game.setup(800,250)
t.bgcolor('black')
g1=11
def newtime():#保持时间与外界同步，弥补程序运行导致的时间误差
    global set1
    global set2
    global set3
    global a
    global b
    global c
    global d
    global e
    global f
    global g1
    tm=dt.datetime.today()
    set3=tm.strftime('%S')
    set2=tm.strftime('%M')
    set1=tm.strftime('%H')
    a=set1[0]
    b=set1[1]
    c=set2[0]
    d=set2[1]
    e=set3[0]
    f=set3[1]
    g1=-g1
    t.ontimer(newtime,1000)

class Penx(t.Pen):
    def state(self,x,y):#只用运行一次的定位函数
        self.reset()
        t.tracer(False)
        self.pu()
        self.goto(x,y)       
        t.tracer(True)
    def change(self,num):#这里的num是位置号，位置号为3或6的辉光管是点号
        self.shape('{}.gif'.format(num))

def auto_renew36():
    global g1
    global a
    global b
    global c
    global d
    global e
    global f
    p1.change(a)
    p1.hideturtle()
    p1.showturtle()
    p2.change(b)
    p2.hideturtle()
    p2.showturtle()
    p4.change(c)
    p4.hideturtle()
    p4.showturtle()
    p5.change(d)
    p5.hideturtle()
    p5.showturtle()
    p7.change(e)
    p7.hideturtle()
    p7.showturtle()
    p8.change(f)
    p8.hideturtle()
    p8.showturtle()
    
    p3.change(g1)
    p6.change(g1)
    p3.hideturtle()
    p6.hideturtle()
    p6.showturtle()
    p3.showturtle()
    t.ontimer(auto_renew36,1000)

#-------------------------主程序--------------------------------
p1=Penx()
p1.state(-300,0)
p2=Penx()
p2.state(-220,0)
p4=Penx()
p4.state(-60,0)
p5=Penx()
p5.state(20,0)
p7=Penx()
p7.state(180,0)
p8=Penx()
p8.state(260,0)
p3=Penx()
p3.state(-140,0)
p6=Penx()
p6.state(100,0)

begin = threading.Thread(target=newtime)
begin.start()
pen36 = threading.Thread(target=auto_renew36)
pen36.start()

game.mainloop()
game.done()
    
