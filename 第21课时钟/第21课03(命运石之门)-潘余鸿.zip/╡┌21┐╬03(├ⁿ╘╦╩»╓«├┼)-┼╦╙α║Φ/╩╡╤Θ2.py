#八只画笔
import turtle as t
t.register_shape('0.gif')#分别申请三支画笔画三个运动体
t1 = t.Pen()
t1.shape('0.gif')
t1.pu()
t1.fd(300)
class Penx(t.Pen):
    def state(self,x,y):
        self.reset()
        t.tracer(False)
        self.goto(x,y)       
        t.tracer(True)



p1=Penx().state(200,200)
