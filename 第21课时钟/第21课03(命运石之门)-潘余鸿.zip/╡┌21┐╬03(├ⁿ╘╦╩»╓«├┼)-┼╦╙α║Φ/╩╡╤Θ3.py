#八只画笔
import turtle as t
for i in range(12):#登记图像
    t.register_shape('{}.gif'.format(i))
game =t.Screen()
game.title("走迷宫")
game.bgcolor("black")
game.setup(800,250)
t.bgcolor('black')
class Penx(t.Pen):
    def state(self,x,y):#只用运行一次的定位函数
        self.reset()
        t.tracer(False)
        self.pu()
        self.goto(x,y)       
        t.tracer(True)
    def change(self,num):#这里的num是位置号，位置号为3或6的辉光管是点号
        self.shape('{}.gif'.format(num))
        


p1=Penx().state(-300,0)
p1.change(1)

p2=Penx()
p2.state(-200,200)
p2.change(2)

p1=Penx()
p1.state(-100,200)
p1.change(1)

p1=Penx()
p1.state(0,200)
p1.change(1)

p1=Penx()
p1.state(200,200)
p1.change(1)
'''
p1=Penx().state(200,200)
p1.change
p2=Penx().state(-200,200)
p3=Penx().state(200,200)
p4=Penx().state(200,200)
p5=Penx().state(200,200)
p6=Penx().state(200,200)
p7=Penx().state(200,200)
p8=Penx().state(200,200)
'''
