# -*- coding:utf-8 -*-
"""
作者：潘余鸿
日期：2023年11月28日
"""
import time
import pygame
import sys
import random
import datetime as dt

# pygame初始化
pygame.init()
# 主窗口
screen_image = pygame.display.set_mode((1200, 800))
# 标题
pygame.display.set_caption('pygame版游戏')


# 飞船
class Ship(object):
    def __init__(self, image):
        self.ship_image = pygame.image.load(image)  # 引入图像
        self.ship_rect = self.ship_image.get_rect()  # 获取坐标数值
        self.ship_mask = pygame.mask.from_surface(self.ship_image)  # 设置遮罩
        pygame.mouse.set_visible(False)  # 隐藏鼠标

    # 飞船移动
    def __move__(self):
        for event in pygame.event.get():  # 返回一个窗口中待处理事件列表，遍历它
            if event.type == pygame.QUIT:  # 找出关闭窗口的情况
                sys.exit()
            elif event.type == pygame.MOUSEMOTION:  # 找出鼠标移动的情况
                self.ship_rect.x = event.pos[0]
                self.ship_rect.y = event.pos[1]


# 陨石
class Stone(object):
    def __init__(self, image):
        self.seppd = random.randint(0, 1)  # 可以为陨石设置移动速度,但只能移动整个像素，会导致速度过快，不建议改
        self.stone_image = pygame.image.load(image)  # 引入图像
        self.stone_rect = self.stone_image.get_rect()  # 获取坐标数值
        self.stone_rect.center = (random.randint(50, 1150), 0)  # 二者同中心
        self.stone_mask = pygame.mask.from_surface(self.stone_image)  # 为陨石设置遮罩

    # 陨石移动
    def __move__(self):
        global hitpoint
        for ship in ships:  # 所有飞船都计算一次碰撞，算法是遮罩重叠
            if self.stone_mask.overlap(ships[ship].ship_mask, (self.stone_rect.x + 55 - ships[ship].ship_rect.x,
                                                               self.stone_rect.y + 20 - ships[
                                                                   ship].ship_rect.y)) or self.stone_mask.overlap(
                    ships[ship].ship_mask, (1200 - self.stone_rect.x + 55 - ships[ship].ship_rect.x,
                                            self.stone_rect.y + 20 - ships[ship].ship_rect.y)):

                hitpoint -= 1  # 每一个像素碰到陨石都会扣一滴血
            else:
                self.stone_rect.y += random.randint(0, 1)  # 在这里可以用self.speed使用陨石对象的固定速度，还是不建议把速度设置固定，0不动，超过1太快
        if self.stone_rect.top > 1200:  # 如果超越屏幕就再自动生成一个
            self.stone_rect.x = random.randint(0, 1200 - 50)
            self.stone_rect.y = random.randint(-100, -50)


class Word(object):

    # 获取准确时间计算秒数
    global tm
    font = pygame.font.Font('freesansbold.ttf', 32)
    first_time = dt.datetime.now()

    def __init__(self, text, x, y, size):
        self.txt_font = pygame.font.SysFont(None, size)
        self.txt_image = self.txt_font.render(text, True, (0, 0, 0), (255, 255, 255))
        self.txt_rect = self.txt_image.get_rect()
        self.txt_rect.x = x
        self.txt_rect.y = y
        self.font = pygame.font.Font('freesansbold.ttf', 32)

    # 显示血量
    @classmethod
    def __showhitpoint__(cls):
        global hitpoint
        text = f"HP={hitpoint}"
        hitpoint_render = Word.font.render(text, True, (255, 0, 0))
        screen_image.blit(hitpoint_render, (520, 50))  # 保持渲染

    # 显示时间
    @classmethod
    def __showtime__(cls):
        tm = dt.datetime.today()
        time_difference = tm - Word.first_time
        time_difference_seconds = time_difference.total_seconds()  # 把单位换成秒
        time_difference_formatted = "{:.2f}".format(time_difference_seconds)  # 精确到0.01s
        text2 = f"TIME={time_difference_formatted}S"
        hitpoint_render = Word.font.render(text2, True, (0, 255, 0))
        screen_image.blit(hitpoint_render, (520, 15))  # 保持渲染


class Game(object):
    # 类属性与数据
    global stones
    global ships
    global hitpoint
    background = pygame.image.load('5.png')
    background2 = pygame.image.load('1.png')
    stones = {}  # 便于使用陨石对象的全局字典
    ships = {}  # 便于使用飞船对象的全局字典
    hitpoint = 4000  # 菜的话可以改血量

    def __init__(self):
        for _ in range(10):
            stones[f"stone{_}"] = Stone("2.png")
        for _ in range(2):
            ships[f"ship{_}"] = Ship("3.png")

    # 启动方法
    @staticmethod
    def __gamestart__():
        # 给玩家一秒准备时间
        time.sleep(1)

        # 血量大于0才能运行
        while hitpoint >= 0:
            # 绘制背景板
            screen_image.blit(Game.background, (0, 0))
            screen_image.blit(Game.background2, (600, 0))

            # 显示文字
            Word.__showtime__()
            Word.__showhitpoint__()

            # 移动飞船
            ships[f"ship{0}"].__move__()
            screen_image.blit(ships[f"ship{0}"].ship_image,
                              (ships[f"ship{0}"].ship_rect.x, ships[f"ship{0}"].ship_rect.y))
            screen_image.blit(ships[f"ship{0}"].ship_image,
                              (1200 - ships[f"ship{0}"].ship_rect.x, ships[f"ship{0}"].ship_rect.y))  # 画谁，在哪画

            # 所有陨石下落
            for i in range(len(stones)):
                stones[f"stone{i}"].__move__()
            for j in range(len(stones)):
                screen_image.blit(stones[f"stone{j}"].stone_image, stones[f"stone{j}"].stone_rect)  # (在哪画，颜色，画谁)
            pygame.display.flip()  # 屏幕刷新

# 启动！
Game().__gamestart__()
