'''
林子卓
'''
#碰撞设计
#------------------------原理:动量定理------------碰撞时水平于面的速度不变，垂直于面的速度取反-------------
import pygame
import random

#----------------------最小游戏单元---------------------
pygame.init()
screen_image = pygame.display.set_mode((800, 600))
pygame.display.set_caption('碰撞')
screen_image.fill((255, 255, 255))
pygame.display.flip()
#-----------------初始坐标和位移距离 mun用来控速--------------------
mx = 100
my = 200
ma = 1
mb = 1
mun = 0
while True:
    mun += 1
    if mun % 10 == 0:
        pygame.draw.circle(screen_image, (255, 255, 255), (mx, my), 20, 0)
        mx += ma
        my += mb
        #-----------------到达边界值后去改变位移方向-----------------------------
        if mx == 800 - 20 or mx == 20:
            ma = - ma
        if my == 600 - 20 or my == 20:
            mb = - mb
        pygame.draw.circle(screen_image, (0, 0, 0), (mx, my), 20, 0)
        pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
