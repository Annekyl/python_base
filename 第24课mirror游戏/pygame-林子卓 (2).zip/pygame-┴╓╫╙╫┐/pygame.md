# python的pygame模块

`pygame`是`python`做**2D**游戏的**第三方库**

## 游戏创作流程

### 游戏初始化

```python
import pygame
import sys

#对系统初始化
pygame.init()
#创建游戏窗口
#display是pygame的显示模块   窗口与turtle不同左上角坐标为0，0
screen_image = pygame.display.set_mode((800,800))
#设置游戏标题
pygame.display.set_caption('迷宫')
#fill是pygame的填充方法
#元组内内容是三原色组成的颜色，python中还支持用字符串来直接表示颜色
screen_image.fill((0, 128, 128))
#刷新游戏界面
#第一次刷新使用flip 二次以后的刷新最好使用update方法
pygame.display.flip()
#设置循环让游戏保持一直运行的状态
while True:
    # event是pygame的事件模块
    for event in pygame.event.get():
        #type是事件类型
        #QUIT是退出事件
        if event.type == pygame.QUIT:
            sys.exit()#exit()方法是退出线程的方法
```

`pygame`的窗口采用的是**笛卡尔坐标系**

与`turtle`不同

<!--游戏初始化很固定，记下来就好-->

### 插入图片

```python
tupian == pygame.image.load('图片路径')
```

<!--加载了图片需要主动渲染-->

```python
窗口.blit(渲染对象,位置)
```

此处注意位置应为**笛卡尔坐标系** 

<!--渲染图片后可以对图片进行操作，但是显示需要去刷新页面-->

### 操作图片

**获取图片大小**

```python
w,h == 图片.get_size()
print(w,h)
```

**对图片进行旋转和缩放**  

```python
pygame.transform.scale(缩放对象, 目标大小)#transfrom是pygame的形变模块    scale是纯缩放方法
```

<!--如果不按比例进行缩放图片会变形-->

```python
pygame.transform.rotozoom(对象, 旋转角度, 缩放比例)#缩放+旋转
```

<!--rotozoom方法仅支持按比例缩放-->

### 显示文字

创建**字体对象** 

```python
font == pygame.font.SysFont()#系统字体
font == pygame.font.Font(字体文件路径, 字体大小)#自创字体
```

创建**文字对象**

```python
text == font.render(文本内容, True , 文字颜色 ,背景颜色)
```

渲染

```python
窗口.blit(文字对象, 位置)
```

处理文字对象的方法与处理图片对象的方法完全相同

### 显示图形

**画直线**

```python
pygame.draw.line(画在哪, 线的颜色, 线的起点, 线的终点, 线宽)#与turtle不同，两点确定一直线
```

<!--这里的画在哪不是画在哪个坐标，是画在哪个窗口上-->

**画折线**<!--同时画多条线-->

```python
points = [(1, 2), (1, 3), (1, 5)]
pygame.draw.lines(画在哪, 线的颜色, 是否闭合 True or False, 多个点坐标, 线宽)
```

<!--按给定的点的坐标按顺序连接起来-->

**画圆**

```python
pygame.draw.circle(画在哪, 颜色, 圆心坐标, 半径, 线宽)#此处线宽默认为0 0为填充
```

**画矩形**

```python
pygame.draw.rect(画在哪, 颜色, 矩形范围, 线宽)#此处默认还是0
```

<!--一个点端点的坐标，提供高度和宽度-->

**画椭圆**

```python
pygame.draw.ellipse(画在哪, 颜色, 椭圆范围, 线宽)#此处默认还是0
```

<!--此处画椭圆的实质为画矩形的内切椭圆-->

也可以把长宽理解为椭圆第一定义的长短轴

**画弧线**

<!--椭圆弧-->

```python
pygame.draw.arc(画在哪, 颜色, 椭圆范围, 起始弧度, 终止弧度, 线宽)#弧度弧度！！！注意此处是弧度！！！！
```

## 鼠标事件

```python
if event.type == pygame.MOUSEBUTTONDOWN#点下鼠标的事件
if event.type == pygame.MOUSEBUTTONUP#鼠标弹起事件
if event.type == pygame.MOUSEMOTTON#鼠标移动事件
```

**获取鼠标坐标**

```python
event.pos#鼠标的位置属性
```

## 键盘事件

```python
if event.type == pygame.KEYUP#弹起按键
if event.type == pygame.KEYDOWN#按下键盘
```

**键信息**

```python
event.key#按键信息属性
```

<!--注意这个属性输出的是按键ASCII码值，此处注意大小写-->

`chr()`可以将编码转化为字符
