import pygame
import sys
import random


pygame.init()
screen_image = pygame.display.set_mode((800,800))
pygame.display.set_caption('迷人的色彩')
screen_image.fill((255, 255, 255))
pygame.display.flip()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        if event.type == pygame.MOUSEMOTION:
            mx, my = event.pos
            a = random.randint(0,255)
            b = random.randint(0, 255)
            c = random.randint(0, 255)
            pygame.draw.circle(screen_image, (a, b, c), (mx, my), 50)
            pygame.display.update()

