import pygame
import random


class Window(object):
    def __init__(self):
        #---------------------初始化pygame窗口----------------------
        super().__init__()
        pygame.init()
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption('Mirror')
        self.screen.fill((255, 255, 255))
        pygame.draw.rect(self.screen, (0, 0, 0), (400, 0, 400, 600))
        pygame.display.flip()
        self.mx = 0
        self.my = 0

    def run(self):
        #------------------------游戏主程序---------------------------
        while True:
            for event in pygame.event.get():#遍历事件
                if event.type == pygame.QUIT:#退出按钮
                    exit()
                if event.type == pygame.MOUSEMOTION:
                    self.mx, self.my = event.pos #鼠标的横纵坐标
                    #print(self.mx)
                    self.qiu(self.mx, self.my)#生成两只对称的小球
            oj1.speed()#三个下落物运动和撞击判断
            oj2.speed()
            oj3.speed()

    def qiu(self, mx, my):#根据横坐标更换笔的颜色
        if mx >= 420:
            pygame.draw.circle(self.screen, (255, 255, 255), (mx, my), c)#先填充刷新页面后擦去
            pygame.draw.circle(self.screen, (0, 0, 0), (800 - mx, my), c)
            pygame.display.update()
            pygame.draw.circle(self.screen, (0, 0, 0), (mx, my), c)
            pygame.draw.circle(self.screen, (255, 255, 255), (800 - mx, my), c)
        elif mx <= 380:
            pygame.draw.circle(self.screen, (0, 0, 0), (mx, my), c)
            pygame.draw.circle(self.screen, (255, 255, 255), (800 - mx, my), c)
            pygame.display.update()
            pygame.draw.circle(self.screen, (255, 255, 255), (mx, my), c)
            pygame.draw.circle(self.screen, (0, 0, 0), (800 - mx, my), c)


class Oj(object):
    def __init__(self):
        super().__init__()
        self.x = random.randint(0, 800)#随机初始横坐标
        self.y = -20#初始纵坐标
        self.v = random.randint(2, 5)#随机速度
        self.cl = (0, 0, 0)#填充颜色
        self.cl1 = (0, 0, 0)#覆盖颜色
        self.mun = 0
        if self.x >= 420:#根据横坐标去变换下落物的颜色
            self.cl = (255, 255, 255)
            self.cl1 = (0, 0, 0)
        if self.x <= 380:
            self.cl = (0, 0, 0)
            self.cl1 = (255, 255, 255)
        if(380 < self.x < 420):#在中间的下落物回炉重造
            self.__init__()

    def speed(self):
        self.mun +=1
        if self.mun % 10000 == 0:#因为time模块的sleep会影响到捕获事件的发生，所以这里用这种方法来调整速度
            pygame.draw.rect(window.screen, self.cl1, (self.x, self.y, 10, 30))#先覆盖
            self.y += self.v
            pygame.draw.rect(window.screen, self.cl, (self.x, self.y, 10, 30))#再画新的
            pygame.display.update()#刷新页面
        if ((self.x + 5 - window.mx)**2 + (self.y + 15 - window.my)**2 <= 900) or ((self.x + 5 + window.mx - 800)**2 + (self.y + 15 - window.my)**2 <= 900):
                print('你输了')#撞击判断
                exit()#退出游戏
        if self.y >= 600:#落到最低端回炉重造
            self.__init__()


c = 20#两只小球的半径
window = Window()
oj1 = Oj()#三个下落物
oj2 = Oj()
oj3 = Oj()
window.run()#主循环